package com.create.industry.config;
public final class ConfigKeys { private ConfigKeys() {} }
