package com.create.industry.data;

public enum MachineType {
    FUEL_GEN, SOLAR_GEN, WIND_GEN, HYDRO_GEN,
    BATTERY_BASIC, BATTERY_ADV,
    AUTO_MINER, MACERATOR, COMPRESSOR, ASSEMBLER,
    PUMP, COOLING_TOWER, MAT_CONVERTER
}
