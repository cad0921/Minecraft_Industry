package com.create.industry.data;

public record MachineId(String id) { @Override public String toString() { return id; } }
